<template>
    <div>
      <el-page-header @back="goback()" title="上一页">

      </el-page-header>
      <dev id="Demo">
        <el-button type="primary" size="medium"  @click="init()">初始化</el-button>
        <el-button type="primary" size="medium"  @click="getUserInfoByIdcard()">扫描身份证获取个人信息</el-button>
        <el-button type="primary" size="medium"  @click="getSerialNumber()">获取设备sn</el-button>
        <el-button type="primary" size="medium"  @click="getAuthNoByFace()">刷脸获取AuthNo</el-button>
        <el-button type="primary" size="medium"  @click="activeECByFace()">刷脸激活电子凭证</el-button>
        <el-button type="primary" size="medium"  @click="getUserInfoByFace()">刷脸获取用户信息</el-button>
        <el-button type="primary" size="medium"  @click="getUserInfoByEC()">扫码凭证获取用户信息</el-button>
        <el-button type="primary" size="medium"  @click="getlocalService()">请求本地服务</el-button>
        <el-button type="primary" size="medium"  @click="refresh()">刷新</el-button>
        <my-dialog :visible.sync="dialogFormVisible" :result="result"></my-dialog>
      </dev>
    </div>

  </template>

  <style>
  #Demo .el-button--primary {
    padding: 10px 15px;
    font-size: 18px;
    border-radius: 3px;
    width: -webkit-fill-available;
    margin-left: 10px;
    width: 300px;
    border: 10px solid;
  }

  #Demo {
    width: 720px;
    height: 1440px;
  }
  </style>

  <script>
//   import { YW } from '../utils/jyw.min.dev'
//   import { YW } from '../utils/jyw.min'
  import MyDialog from './MyDialog.vue'
  export default {
    name: 'Demo',
    data () {
      return {
        dialogFormVisible: false,
        result: '',
        title: ''
      }
    },
    components: {
      MyDialog
    },
    methods: {
      init () {
        // 初始化
        this.$YW.init({
          appId: '',
          isvId: '',
          serverPublicKey: '',
          isvPrivateKey: '',
          isvSecretKey: '',
          success: (res) => {
            // console.log(res)
            this.dialogFormVisible = false
            this.title = "初始化返回"
            console.info("初始化成功")
          },
          fail: (err) => {
            this.dialogFormVisible = true
            this.title = "初始化返回"
            this.result = err || '失败'
            console.info("初始化成功")
          }
        })
      },
      getlocalService () {

      },
      getUserInfoByIdcard () {
        // 扫描身份证获取个人信息
        this.$YW.getUserInfoByIdcard({
          success: (res) => {
            // console.log(res)
            this.dialogFormVisible = true
            this.result = res || '成功'
          },
          fail: (err) => {
            this.dialogFormVisible = true
            this.result = err || '失败'
          }
        })
      },
      getSerialNumber () {
        // 获取设备sn
        this.$YW.getSerialNumber({
          success: (res) => {
            // console.log(res)
            this.dialogFormVisible = true
            this.result = res || '成功'
          },
          fail: (err) => {
            this.dialogFormVisible = true
            this.result = err || '失败'
          }
        })
      },
      getAuthNoByFace () {
        // 刷脸获取AuthNo
        this.$YW.getAuthNoByFace({
          orgId: '13404913730',
          operatorId: 'test001',
          operatorName: ' ',
          outBizNo: '20201222200000',
          businessType: '01101',
          officeId: '32760',
          officeName: ' ',
          success: (res) => {
            // console.log(res)
            this.dialogFormVisible = true
            this.result = res || '成功'
          },
          fail: (err) => {
            this.dialogFormVisible = true
            this.result = err || '失败'
          }
        })
      },
      activeECByFace () {
        // 刷脸激活电子凭证
        this.$YW.activeECByFace({
          success: (res) => {
            // console.log(res)
            this.dialogFormVisible = true
            this.result = res || '成功'
          },
          fail: (err) => {
            this.dialogFormVisible = true
            this.result = err || '失败'
          }
        })
      },
      getUserInfoByFace () {
        // 刷脸获取用户信息
        this.$YW.getUserInfoByFace({
          success: (res) => {
            // console.log(res)
            this.dialogFormVisible = true
            this.result = res || '成功'
          },
          fail: (err) => {
            this.dialogFormVisible = true
            this.result = err || '失败'
          }
        })
      },
      getUserInfoByEC () {
        // 扫码凭证获取用户信息
        this.$YW.getUserInfoByEC({
          success: (res) => {
            // console.log(res)
            this.dialogFormVisible = true
            this.result = res || '成功'
          },
          fail: (err) => {
            this.dialogFormVisible = true
            this.result = err || '失败'
          }
        })
      },
      goback () {
        window.history.go(-1)
      },
      refresh () {
        location.reload()
      },
      onSubmit () {
        this.dialogFormVisible = false
      }
    },
    mounted () {

    //   this.init();
    }
  }
  </script>
