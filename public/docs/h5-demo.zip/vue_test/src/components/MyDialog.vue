
<template>
  <el-dialog title="返回值" :visible.sync="dialogVisible">
        <div>{{ result }}</div>
        <div slot="footer" class="dialog-footer">
      <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="success" @click="onSubmit">确定</el-button>
        </div>
    </el-dialog>
</template>

<script>
export default {
  name: 'MyDialog',
  props: ['visible', 'result'],
  computed: {
    dialogVisible: {
      get () {
        return this.visible
      },
      set (visible) {
        this.$emit('update:visible', visible)
      }
    }
  },
  methods: {
    onSubmit () {
      this.dialogVisible = false
    }
  }
}
</script>
