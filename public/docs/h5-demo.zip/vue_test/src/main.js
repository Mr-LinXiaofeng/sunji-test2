// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import VueAMap from 'vue-amap'
const { YW: nativeYW } = require('./utils/jyw.min')
const { YW: developmentYW } = require('./utils/jyw.min.dev')
const YW = process.env.NODE_ENV === 'development'
	? developmentYW
	: nativeYW

Vue.use(ElementUI)
Vue.use(VueAMap)
Vue.prototype.$YW = YW

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})

VueAMap.initAMapApiLoader({
	// 高德的key
	key: 'key',
	// 插件集合
	plugin: [
		'AMap.CircleEditor', // 圆形编辑器插件
		"AMap.Geolocation", // 定位控件，用来获取和展示用户主机所在的经纬度位置
		"AMap.Geocoder", // 地理编码与逆地理编码服务，用于地址描述与坐标间的相互转换
		"AMap.Autocomplete",
		"AMap.PlaceSearch",
		"AMap.CitySearch"
	],
	// 高德 sdk 版本，默认为 1.4.4
	v: '1.4.4'
})
// 高德的安全密钥
window._AMapSecurityConfig = {
	securityJsCode: 'd4332e5adb8b584442266763d20b978c'
}
