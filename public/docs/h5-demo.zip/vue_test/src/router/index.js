import Vue from 'vue'
import Router from 'vue-router'
import Demo from '../components/Demo.vue'

Vue.use(Router)

export default new Router({
  routes: [

    {
      path: '/Demo',
      name: 'Demo',
      component: Demo
    },

    {
      path: '/',
      name: 'Demo',
      component: Demo
    }

  ]
})
