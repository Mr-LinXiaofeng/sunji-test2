/*
 * @Author: lvlongfei
 * @Date: 2022-09-02 09:20:30
 */
;(function (global, factory) {
  typeof module !== 'undefined' && typeof exports === 'object' ? module.exports = factory() :
  typeof define === 'function' && (define.cmd || define.amd) ? define(factory) :
  (global.YW = factory());
}(this, (function () {
	  var fn_obj = {
			init: function(obj){ //初始化方法 认证(密钥验证)
				obj.success({
					message: '初始化成功'
				})
			},
			getSerialNumber: function(obj){ //获取设备sn
				var result = {
					serialNumber: 'SYDT3M0H2163IR6YA5C'
				}
				obj.success(result)
				obj.fail(result)
			},
			getYBNumber: function(obj){ //获取医保sn
				var result = {
					ybSn: '3EW99E06216310000062'
				}
				obj.success(result)
				obj.fail(result)
			},
			getUserInfoByIdcard: function(obj){ //扫描身份证获取个人信息
				var result = {
					certName: '测试A',
					certNo: '13052319920611xxxx'
				}
				obj.success(result)
				obj.fail(result)
			},
			getAuthNoByFace: function(obj){ //刷脸获取AuthNo 
				var result = {
					authNo: 'authNo'
				}
				obj.success(result)
				obj.fail(result)
			},
			activeECByFace: function(obj){ //刷脸激活电子凭证
				var result = {
					data: '成功'
				}
				obj.success(result)
				obj.fail(result)
			},
			getUserInfoByFace: function(obj){ //刷脸获取用户信息
				var result = {
					ecToken: 'ecToken',
					idNo: 'idNo',
					idType: 'idType',
					userName: 'userName',
					insuOrg: 'insuOrg',
					insCityCode: 'insCityCode',
					ecIndexNo: 'ecIndexNo',
					chnlId: 'chnlId',
					ecQrCode: 'ecQrCode',
					gender: 'gender',
					birthday: 'birthday',
					nationality: 'nationality',
					email: 'email'
				}
				obj.success(result)
				obj.fail(result)
			},
			getUserInfoByEC: function(obj){ //扫码凭证获取用户信息
				var result = {
					ecToken: 'ecToken',
					idNo: 'idNo',
					idType: 'idType',
					userName: 'userName',
					insuOrg: 'insuOrg',
					ecIndexNo: 'ecIndexNo',
					chnlId: 'chnlId',
					ecQrCode: 'ecQrCode',
					gender: 'gender',
					birthday: 'birthday',
					nationality: 'nationality',
					email: 'email'
				}
				obj.success(result)
				obj.fail(result)
			},
			getScanCode: function(obj){ //打开扫码墩页面
				var result = {
					scanCode: 'scanCode'
				}
				obj.success(result)
				obj.fail(result)
			},
			print: function(obj){ //打印
				alert('打印成功:' + obj)
			},
			backHome: function(){ //回到首页
				alert('回到首页成功')
			},
			setTouchTimeout: function(obj){ //无操作超时处理
				alert('无操作超时处理设置成功:' + obj)
			},
			getMac: function(obj){ //获取设备的mac地址
				var result = {
					mac: 'mac'
				}
				obj.success(result)
				obj.fail(result)
			}
		}
		return fn_obj
  }
)));